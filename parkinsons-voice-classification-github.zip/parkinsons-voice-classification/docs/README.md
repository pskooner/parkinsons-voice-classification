# Documentation

The original final report is not included in this public-ready version because the submitted document contains student identification numbers and course-submission details.

For a public portfolio, the repository `README.md` summarizes the project, methods, and main results without those identifiers.
